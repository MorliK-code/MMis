﻿from __future__ import annotations

import copy
import json
from typing import Any

from PySide6.QtCore import QEvent, QPoint, QRectF, Qt, Signal
from PySide6.QtGui import QPainter, QPen
from PySide6.QtWidgets import (
    QDialog,
    QFrame,
    QGraphicsBlurEffect,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from ui.client.settings_facade import SettingsFacade
from ui.chat_shell import ChatScrollOverlay, PlainTextScrollOverlay, _to_qcolor, _ui_font
from ui.settings_schema import SETTINGS_CATEGORIES, SettingCategory, SettingSpec, dotted_get, get_category
from ui.settings_styles import SETTINGS_STYLE
from ui.settings_widgets import SettingEditor


class SettingsHintPopup(QFrame):
    def __init__(self, parent: QWidget):
        super().__init__(parent)
        self.setObjectName("settings_hint_popup")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setFixedWidth(314)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(7)
        self.title_label = QLabel("")
        self.title_label.setObjectName("hint_popup_title")
        self.body_label = QLabel("")
        self.body_label.setObjectName("hint_popup_body")
        self.body_label.setWordWrap(True)
        self.example_label = QLabel("")
        self.example_label.setObjectName("hint_popup_example")
        self.example_label.setWordWrap(True)
        self.restart_badge = QLabel("restart required")
        self.restart_badge.setObjectName("restart_badge")
        self.updated_badge = QLabel("updated")
        self.updated_badge.setObjectName("updated_badge")
        badge_layout = QHBoxLayout()
        badge_layout.setContentsMargins(0, 0, 0, 0)
        badge_layout.addWidget(self.restart_badge)
        badge_layout.addWidget(self.updated_badge)
        badge_layout.addStretch()

        layout.addWidget(self.title_label)
        layout.addWidget(self.body_label)
        layout.addLayout(badge_layout)
        layout.addWidget(self.example_label)
        self.hide()

    def set_spec(self, spec: SettingSpec, updated: bool = False) -> None:
        for label in (self.title_label, self.body_label, self.example_label):
            label.setMinimumHeight(0)
            label.setMaximumHeight(16777215)
            label.setMinimumWidth(0)
            label.setMaximumWidth(16777215)
        self.title_label.setText(_hint_title(spec))
        self.body_label.setText(_hint_description(spec))
        self.example_label.setText(_hint_example(spec))
        self.example_label.setVisible(bool(self.example_label.text().strip()))
        self.restart_badge.setVisible(bool(spec.restart_required))
        self.updated_badge.setVisible(bool(updated))

    def prepare_for_width(self, width: int) -> int:
        for label in (self.title_label, self.body_label, self.example_label):
            label.setMinimumHeight(0)
            label.setMaximumHeight(16777215)
            label.setMinimumWidth(0)
            label.setMaximumWidth(16777215)
        self.setFixedWidth(width)
        layout = self.layout()
        margins = layout.contentsMargins()
        body_width = max(80, width - margins.left() - margins.right())
        total = margins.top() + margins.bottom()
        spacing = layout.spacing()

        visible_heights: list[int] = []
        for label in (self.title_label, self.body_label, self.example_label):
            if label.isHidden():
                continue
            label.setFixedWidth(body_width)
            height = label.heightForWidth(body_width) if label.wordWrap() else label.sizeHint().height()
            if height < 0:
                height = label.sizeHint().height()
            if label.wordWrap():
                height += 6
            label.setMinimumHeight(height)
            visible_heights.append(height)

        badge_height = 0
        if not self.restart_badge.isHidden() or not self.updated_badge.isHidden():
            badge_height = max(self.restart_badge.sizeHint().height(), self.updated_badge.sizeHint().height())
            visible_heights.insert(2, badge_height)

        total += sum(visible_heights)
        total += spacing * max(0, len(visible_heights) - 1)
        total += 8
        self.resize(width, total)
        return total


class HintButton(QWidget):
    activated = Signal(object)
    hovered = Signal(object)
    unhovered = Signal(object)

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setFixedSize(18, 18)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMouseTracking(True)

    def enterEvent(self, event) -> None:
        self.hovered.emit(self)
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:
        self.unhovered.emit(self)
        super().leaveEvent(event)

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self.activated.emit(self)
            event.accept()
            return
        super().mousePressEvent(event)

    def paintEvent(self, _event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        rect = QRectF(0.5, 0.5, 17.0, 17.0)
        painter.setPen(QPen(_to_qcolor("rgba(139,92,246,.40)"), 1))
        painter.setBrush(_to_qcolor("rgba(139,92,246,.16)"))
        painter.drawEllipse(rect)
        painter.setPen(_to_qcolor("#9f8bff"))
        font = _ui_font(pixel_size=10)
        font.setFamily("Segoe UI")
        painter.setFont(font)
        painter.drawText(QRectF(0.0, -0.5, 18.0, 18.0), int(Qt.AlignmentFlag.AlignCenter), "?")


class SettingsWindow(QDialog):
    saved = Signal(dict)

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setObjectName("settings_window")
        self.setWindowTitle("РќР°СЃС‚СЂРѕР№РєРё MMis")
        self.setModal(False)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        if parent is not None:
            self.setWindowFlags(Qt.WindowType.Widget)
            parent.installEventFilter(self)
        else:
            self.setWindowFlags(Qt.WindowType.Dialog | Qt.WindowType.FramelessWindowHint)
        self.resize(1200, 820)
        self._payload: dict[str, Any] = {}
        self.api = getattr(parent, "api", None)
        self.settings = SettingsFacade(api=self.api)
        self._api_online = False
        self._has_cache = False
        self._pending: dict[str, Any] = {}
        self._panel: QFrame | None = None
        self._blur_target: QWidget | None = None
        self._scroll_overlay: ChatScrollOverlay | None = None
        self._hint_popup: SettingsHintPopup | None = None
        self._hint_targets: dict[QWidget, SettingSpec] = {}
        self._category_key = SETTINGS_CATEGORIES[0].key
        self._editors: dict[str, SettingEditor] = {}
        self._changed: dict[str, Any] = {}
        self._invalid: dict[str, str] = {}
        self._labels: dict[str, QLabel] = {}
        self._nav_buttons: dict[str, QPushButton] = {}
        self._search_text = ""
        self._build_ui()
        self.reload()

    def reload(self) -> None:
        self.settings.api = getattr(self.parentWidget(), "api", self.api)
        result = self.settings.load()
        self._payload = result.payload
        self._api_online = result.api_online
        self._has_cache = result.has_cache
        self._pending = result.pending
        self._changed.clear()
        self._invalid.clear()
        self._build_nav()
        if self._category_key not in self._available_category_keys():
            self._category_key = "connection"
        self._render_category()
        self._refresh_preview()

    def _build_ui(self) -> None:
        self.setStyleSheet(SETTINGS_STYLE)
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        overlay = QFrame(self)
        overlay.setObjectName("settings_overlay")
        overlay.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        root.addWidget(overlay)
        overlay_layout = QVBoxLayout(overlay)
        overlay_layout.setContentsMargins(0, 0, 0, 0)
        overlay_layout.setSpacing(0)

        panel = QFrame(overlay)
        self._panel = panel
        panel.setObjectName("settings_panel")
        panel.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        panel.setMaximumSize(1360, 750)
        overlay_layout.addWidget(panel, 0, Qt.AlignmentFlag.AlignCenter)
        panel_layout = QVBoxLayout(panel)
        panel_layout.setContentsMargins(0, 0, 0, 0)
        panel_layout.setSpacing(0)

        top = QFrame(panel)
        top.setObjectName("settings_top")
        top.setFixedHeight(58)
        top_layout = QHBoxLayout(top)
        top_layout.setContentsMargins(16, 10, 12, 10)
        top_layout.setSpacing(12)
        gear = QLabel("вљ™")
        gear.setObjectName("settings_gear")
        gear.setAlignment(Qt.AlignmentFlag.AlignCenter)
        top_layout.addWidget(gear, 0)
        title_col = QVBoxLayout()
        title = QLabel("РќР°СЃС‚СЂРѕР№РєРё MMis")
        title.setObjectName("settings_title")
        subtitle = QLabel("РџРѕР»СѓРїСЂРѕР·СЂР°С‡РЅРѕРµ РѕРєРЅРѕ РїРѕРІРµСЂС… РѕСЃРЅРѕРІРЅРѕРіРѕ UI - config/settings.py + config.json")
        subtitle.setObjectName("settings_subtitle")
        title_col.addWidget(title)
        title_col.addWidget(subtitle)
        top_layout.addLayout(title_col, 1)
        self.search = QLineEdit(top)
        self.search.setObjectName("settings_search")
        self.search.setPlaceholderText("РџРѕРёСЃРє: memory top_k, ollama, voice...")
        self.search.setFixedWidth(324)
        self.search.textChanged.connect(self._on_search)
        top_layout.addWidget(self.search, 0)
        close_btn = QToolButton(top)
        close_btn.setText("x")
        close_btn.setObjectName("close_button")
        close_btn.clicked.connect(self.close)
        top_layout.addWidget(close_btn, 0)
        panel_layout.addWidget(top)

        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)
        panel_layout.addLayout(body, 1)

        self.nav = QFrame(panel)
        self.nav.setObjectName("settings_nav")
        self.nav.setFixedWidth(196)
        self.nav_layout = QVBoxLayout(self.nav)
        self.nav_layout.setContentsMargins(14, 14, 10, 14)
        self.nav_layout.setSpacing(4)
        self._build_nav()
        body.addWidget(self.nav)

        center = QWidget(panel)
        center.setObjectName("settings_center")
        center.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        center_layout = QVBoxLayout(center)
        center_layout.setContentsMargins(14, 12, 10, 0)
        center_layout.setSpacing(9)
        header = QHBoxLayout()
        self.category_title = QLabel("")
        self.category_title.setObjectName("settings_title")
        self.category_desc = QLabel("")
        self.category_desc.setObjectName("settings_muted")
        self.category_desc.setWordWrap(True)
        header_text = QVBoxLayout()
        header_text.addWidget(self.category_title)
        header_text.addWidget(self.category_desc)
        header.addLayout(header_text, 1)
        reset_btn = QPushButton("РЎР±СЂРѕСЃРёС‚СЊ")
        reset_btn.clicked.connect(self.reload)
        self.save_btn = QPushButton("РЎРѕС…СЂР°РЅРёС‚СЊ")
        self.save_btn.setObjectName("primary_button")
        self.save_btn.clicked.connect(self._save)
        header.addWidget(reset_btn)
        header.addWidget(self.save_btn)
        center_layout.addLayout(header)

        self.scroll = QScrollArea(center)
        self.scroll.setObjectName("settings_scroll")
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scroll.viewport().setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.scroll.viewport().setAutoFillBackground(False)
        self.content = QWidget()
        self.content.setObjectName("settings_content")
        self.content.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.content_layout = QGridLayout(self.content)
        self.content_layout.setContentsMargins(0, 0, 0, 20)
        self.content_layout.setHorizontalSpacing(8)
        self.content_layout.setVerticalSpacing(10)
        self.scroll.setWidget(self.content)
        self._scroll_overlay = ChatScrollOverlay(self.scroll)
        self.scroll.verticalScrollBar().valueChanged.connect(lambda _value: self._hide_hint_popup())
        center_layout.addWidget(self.scroll, 1)
        body.addWidget(center, 1)

        self.preview_panel = QFrame(panel)
        self.preview_panel.setObjectName("right_panel")
        self.preview_panel.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.preview_panel.setFixedWidth(220)
        preview_layout = QVBoxLayout(self.preview_panel)
        preview_layout.setContentsMargins(10, 12, 10, 12)
        preview_layout.setSpacing(10)
        self.state_label = QLabel("")
        self.state_label.setObjectName("settings_muted")
        self.state_label.setWordWrap(True)
        preview_layout.addWidget(self._preview_card("Р–РёРІРѕРµ СЃРѕСЃС‚РѕСЏРЅРёРµ", self.state_label))
        self.connection_status_label = QLabel("")
        self.connection_status_label.setObjectName("settings_muted")
        self.connection_status_label.setWordWrap(True)
        preview_layout.addWidget(self._preview_card("Client sync", self.connection_status_label))
        self.diff_box = QPlainTextEdit()
        self.diff_box.setObjectName("json_preview")
        self.diff_box.setReadOnly(True)
        self.diff_box.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.diff_box.setViewportMargins(4, 4, 16, 4)
        self._diff_scroll_overlay = PlainTextScrollOverlay(self.diff_box)
        preview_layout.addWidget(self._preview_card("РџСЂРµРґРїСЂРѕСЃРјРѕС‚СЂ JSON", self.diff_box), 1)
        self.warning_label = QLabel("")
        self.warning_label.setObjectName("settings_muted")
        self.warning_label.setWordWrap(True)
        preview_layout.addWidget(self._preview_card("Warnings", self.warning_label))
        ux_label = QLabel("Р›РљРњ РїРѕ ?                         РїРѕРґСЃРєР°Р·РєР°\nРР·РјРµРЅС‘РЅРЅС‹Рµ РїРѕР»СЏ           С„РёРѕР»РµС‚РѕРІР°СЏ РјРµС‚РєР°\nРћРїР°СЃРЅС‹Рµ РїРѕР»СЏ                    РєСЂР°СЃРЅР°СЏ Р·РѕРЅР°\nРЎРѕС…СЂР°РЅРµРЅРёРµ              API / pending queue")
        ux_label.setObjectName("settings_muted")
        ux_label.setWordWrap(True)
        preview_layout.addWidget(self._preview_card("РРґРµСЏ UX", ux_label))
        body.addWidget(self.preview_panel)
        self._hint_popup = SettingsHintPopup(self)

    def showEvent(self, event) -> None:
        self._fit_to_parent()
        self._apply_parent_blur()
        super().showEvent(event)

    def hideEvent(self, event) -> None:
        self._clear_parent_blur()
        super().hideEvent(event)

    def closeEvent(self, event) -> None:
        self._clear_parent_blur()
        super().closeEvent(event)

    def _fit_to_parent(self) -> None:
        parent = self.parentWidget()
        if parent is None:
            self.resize(1200, 820)
            return
            
        is_dialog = bool(self.windowFlags() & Qt.WindowType.Dialog)
        if not is_dialog:
            self.setGeometry(0, 0, parent.width(), parent.height())
        else:
            top_left = parent.mapToGlobal(parent.rect().topLeft())
            self.setGeometry(top_left.x(), top_left.y(), parent.width(), parent.height())
            
        panel_width = max(1060, min(1360, parent.width() - 56))
        panel_height = max(660, min(728, parent.height() - 96))
        if self._panel is not None:
            self._panel.setFixedSize(panel_width, panel_height)

    def _apply_parent_blur(self) -> None:
        parent = self.parentWidget()
        target = parent.centralWidget() if hasattr(parent, "centralWidget") else parent
        if not isinstance(target, QWidget):
            return
        if self._blur_target is target:
            return
        self._clear_parent_blur()
        effect = QGraphicsBlurEffect(target)
        effect.setBlurRadius(7.0)
        effect.setBlurHints(QGraphicsBlurEffect.BlurHint.QualityHint)
        target.setGraphicsEffect(effect)
        self._blur_target = target

    def _clear_parent_blur(self) -> None:
        if self._blur_target is not None:
            self._blur_target.setGraphicsEffect(None)
            self._blur_target = None

    def _build_nav(self) -> None:
        while self.nav_layout.count():
            item = self.nav_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
        current_group = ""
        available = set(self._available_category_keys())
        self._nav_buttons.clear()
        for category in SETTINGS_CATEGORIES:
            if category.key not in available:
                continue
            if category.group != current_group:
                current_group = category.group
                label = QLabel(_group_title(current_group))
                label.setObjectName("settings_muted")
                self.nav_layout.addWidget(label)
            count = sum(len(card.settings) for card in category.cards)
            button = QPushButton(f"{_category_icon(category.key)} {category.title}  {count}")
            button.setObjectName("nav_button")
            button.setProperty("count", str(count))
            button.setCheckable(True)
            button.clicked.connect(lambda _checked=False, key=category.key: self._select_category(key))
            self.nav_layout.addWidget(button)
            self._nav_buttons[category.key] = button
        self.nav_layout.addStretch(1)

    def _available_category_keys(self) -> set[str]:
        if self._api_online or self._has_cache:
            return {category.key for category in SETTINGS_CATEGORIES}
        return {"connection"}

    def _preview_card(self, title: str, widget: QWidget) -> QFrame:
        frame = QFrame(self)
        frame.setObjectName("settings_card")
        frame.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(12, 10, 12, 0)
        layout.setSpacing(8)
        label = QLabel(title)
        label.setObjectName("card_title")
        layout.addWidget(label)
        layout.addWidget(widget, 1)
        layout.addSpacing(14)
        return frame

    def _select_category(self, key: str) -> None:
        self._category_key = key
        self._render_category()

    def _render_category(self) -> None:
        self._hide_hint_popup()
        self._hint_targets.clear()
        for button_key, button in self._nav_buttons.items():
            button.setChecked(button_key == self._category_key)
        self._editors.clear()
        self._labels.clear()
        while self.content_layout.count():
            item = self.content_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
        category = get_category(self._category_key)
        self.category_title.setText(category.title)
        self.category_desc.setText(_category_description(category))
        cards = self._filtered_cards(category)
        if not cards:
            if not self._api_online and not self._has_cache and category.key != "connection":
                empty = QLabel(
                    "Server settings will appear after connecting to MMis API.\n"
                    "For now only connection settings are available."
                )
            else:
                empty = QLabel("No settings match the search.")
            empty.setObjectName("settings_muted")
            self.content_layout.addWidget(empty, 0, 0)
            return
        for index, card in enumerate(cards):
            two_column = index < 2 and len(cards) > 1
            row = index // 2 if two_column else 1 + max(0, index - 2)
            col = index % 2 if two_column else 0
            frame = QFrame(self.content)
            frame.setObjectName("danger_card" if card.dangerous else "settings_card")
            frame.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
            frame.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Minimum)
            layout = QVBoxLayout(frame)
            layout.setContentsMargins(10, 8, 10, 10)
            layout.setSpacing(4)
            header_layout = QHBoxLayout()
            header_layout.setContentsMargins(0, 0, 0, 2)
            title_lbl = QLabel(card.title)
            title_lbl.setObjectName("danger_title" if card.dangerous else "card_title")
            tag_lbl = QLabel(card.tag)
            tag_lbl.setObjectName("card_tag")
            tag_lbl.ensurePolished()
            tag_width = tag_lbl.fontMetrics().horizontalAdvance(tag_lbl.text()) + 14
            tag_lbl.setFixedSize(tag_width, 20)
            header_layout.addWidget(title_lbl)
            header_layout.addStretch()
            header_layout.addWidget(tag_lbl, 0, Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            layout.addLayout(header_layout)
            for spec in card.settings:
                if not self._matches_search(spec, category.title, card.title):
                    continue
                layout.addWidget(self._setting_row(spec))
            layout.addStretch(1)
            colspan = 1 if two_column else 2
            self.content_layout.addWidget(frame, row, col, 1, colspan)
        self.content_layout.setColumnStretch(0, 1)
        self.content_layout.setColumnStretch(1, 1)
        self._refresh_preview()

    def _setting_row(self, spec: SettingSpec) -> QWidget:
        row = QFrame()
        row.setObjectName("setting_row")
        row.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        row.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        row.setFixedHeight(30)
        layout = QHBoxLayout(row)
        layout.setContentsMargins(0, 4, 0, 2)
        layout.setSpacing(6)

        label = QLabel(_setting_title(spec))
        label.setObjectName("setting_label")
        label_font = _ui_font(pixel_size=11)
        label_font.setFamily("Cascadia Code")
        label.setFont(label_font)
        label.ensurePolished()
        label_width = max(44, label.fontMetrics().horizontalAdvance(label.text()) + 17)
        label.setFixedWidth(label_width)
        label.setFixedHeight(18)
        label.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        label.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)

        hint = HintButton()
        hint.setObjectName("hint_button")
        hint.hovered.connect(lambda _button, button=hint: self._show_hint_popup(button, self._hint_targets[button]))
        hint.activated.connect(lambda _button, button=hint: self._show_hint_popup(button, self._hint_targets[button]))
        hint.unhovered.connect(lambda _button: self._hide_hint_popup())
        self._hint_targets[hint] = spec

        layout.addWidget(label, 0, Qt.AlignmentFlag.AlignVCenter)
        layout.addWidget(hint, 0, Qt.AlignmentFlag.AlignVCenter)
        layout.setSpacing(2)
        layout.addStretch(1)

        value = self._changed.get(spec.path, dotted_get(self._payload, spec.path))
        editor = SettingEditor(spec, value, row)
        editor.valueChanged.connect(lambda value, path=spec.path: self._on_editor_changed(path, value))
        control = editor.control()
        control.setMinimumWidth(0)
        layout.addWidget(control, 0, Qt.AlignmentFlag.AlignVCenter)
        self._editors[spec.path] = editor
        self._labels[spec.path] = label
        self._update_badge(spec.path)
        return row

    def eventFilter(self, watched, event) -> bool:
        if watched is self.parentWidget() and event.type() == QEvent.Type.Resize:
            self._fit_to_parent()

        if isinstance(watched, QWidget) and watched in self._hint_targets:
            if event.type() in {QEvent.Type.Enter, QEvent.Type.MouseButtonPress}:
                self._show_hint_popup(watched, self._hint_targets[watched])
            elif event.type() in {QEvent.Type.Leave, QEvent.Type.Hide}:
                self._hide_hint_popup()
        return super().eventFilter(watched, event)

    def _show_hint_popup(self, anchor: QWidget, spec: SettingSpec) -> None:
        if self._hint_popup is None:
            return
        self._hint_popup.set_spec(spec, updated=spec.path in self._changed)
        width = _hint_popup_width(spec)
        height = self._hint_popup.prepare_for_width(width)
        preferred = anchor.mapTo(self, QPoint(-12, anchor.height() + 7))
        panel_rect = self._panel.geometry() if self._panel is not None else self.rect()
        x = max(panel_rect.left() + 12, min(preferred.x(), panel_rect.right() - width - 12))
        y = preferred.y()
        if y + height > panel_rect.bottom() - 12:
            y = anchor.mapTo(self, QPoint(-12, -height - 7)).y()
        y = max(panel_rect.top() + 12, min(y, panel_rect.bottom() - height - 12))
        self._hint_popup.move(x, y)
        self._hint_popup.show()
        self._hint_popup.raise_()

    def _hide_hint_popup(self) -> None:
        if self._hint_popup is not None:
            self._hint_popup.hide()

    def _on_editor_changed(self, path: str, value: Any) -> None:
        editor = self._editors.get(path)
        if editor is not None:
            ok, message = editor.validate_value()
            if ok:
                self._invalid.pop(path, None)
            else:
                self._invalid[path] = message
        original = editor.initial_value() if editor is not None else dotted_get(self._payload, path)
        if value == original:
            self._changed.pop(path, None)
        else:
            self._changed[path] = value
        self._update_badge(path)
        self._refresh_preview()

    def _update_badge(self, path: str) -> None:
        label = self._labels.get(path)
        spec = _spec_for(path)
        changed = path in self._changed
        
        if label:
            label.setObjectName("setting_label_changed" if changed else "setting_label")
            label.style().unpolish(label)
            label.style().polish(label)

    def _refresh_preview(self) -> None:
        api_host = dotted_get(self._payload, "api.host", "")
        api_port = dotted_get(self._payload, "api.port", "")
        profile = dotted_get(self._payload, "startup.active_profile", "")
        model = dotted_get(self._payload, "llm.model_name", "")
        web_mode = dotted_get(self._payload, "internet.web_mode", "")
        active_api = dotted_get(self._payload, "ui.api.active_endpoint", "local")
        local_api = dotted_get(self._payload, "ui.api.local_base_url", "")
        public_api = dotted_get(self._payload, "ui.api.public_base_url", "")
        selected_api = public_api if str(active_api).lower() == "public" else local_api
        connection_url = dotted_get(self._payload, "connection.base_url", "")
        api_text = "online" if self._api_online else "offline"
        cache_text = "yes" if self._has_cache else "no"
        pending_count = len(self._pending)
        self.state_label.setText(
            f"API                                      {connection_url or selected_api or f'{api_host}:{api_port}'}\n"
            f"Profile: {profile}\n"
            f"Memory: enabled\n"
            f"Web: {web_mode}\n"
            f"Voice: qwen/faster-whisper\n"
            f"Changed: {len(self._changed)}"
        )
        if hasattr(self, "connection_status_label"):
            cache_note = "offline cache" if (not self._api_online and self._has_cache) else ""
            self.connection_status_label.setText(
                f"API: {api_text}\n"
                f"Cache: {cache_text} {cache_note}\n"
                f"Pending changes: {pending_count}"
            )
        self.diff_box.setPlainText(json.dumps(self._changed, ensure_ascii=False, indent=2, sort_keys=True))
        warnings: list[str] = []
        for path, message in self._invalid.items():
            warnings.append(f"{path}: invalid value ({message})")
        for path in self._changed:
            spec = _spec_for(path)
            if spec and spec.restart_required:
                warnings.append(f"{path}: restart required")
            if spec and spec.dangerous:
                warnings.append(f"{path}: dangerous setting")
        self.warning_label.setText("\n".join(warnings) if warnings else "No warnings.")
        self.save_btn.setEnabled(bool(self._changed) and not bool(self._invalid))

    def _save(self) -> None:
        updates: dict[str, Any] = {}
        errors: list[str] = []
        for path, message in self._invalid.items():
            errors.append(f"{path}: {message}")
        for path, editor in self._editors.items():
            if path not in self._changed:
                continue
            ok, message = editor.validate_value()
            if not ok:
                errors.append(f"{path}: {message}")
                continue
            updates[path] = editor.value()
        for path, value in self._changed.items():
            if path not in updates and path not in self._editors:
                updates[path] = value
        if errors:
            QMessageBox.warning(self, "Settings validation", "\n".join(errors))
            return
        if not updates:
            return
        self.settings.save(updates)
        self.saved.emit(copy.deepcopy(updates))
        self.reload()

    def _on_search(self, text: str) -> None:
        self._search_text = str(text or "").strip().lower()
        if self._search_text:
            current = get_category(self._category_key)
            if not self._filtered_cards(current):
                for category in SETTINGS_CATEGORIES:
                    if self._filtered_cards(category):
                        self._category_key = category.key
                        break
        self._render_category()

    def _filtered_cards(self, category: SettingCategory):
        if not self._search_text:
            return category.cards
        cards = []
        for card in category.cards:
            if any(self._matches_search(spec, category.title, card.title) for spec in card.settings):
                cards.append(card)
        return tuple(cards)

    def _matches_search(self, spec: SettingSpec, category_title: str, card_title: str) -> bool:
        needle = self._search_text
        if not needle:
            return True
        haystack = " ".join(
            [
                category_title,
                card_title,
                spec.path,
                spec.title,
                spec.description,
                spec.example,
                " ".join(spec.options),
            ]
        ).lower()
        return needle in haystack


def _hint_text(spec: SettingSpec) -> str:
    parts = [_setting_title(spec), _hint_title(spec), _hint_description(spec), _hint_example(spec)]
    return "\n".join(part for part in parts if part)


def _hint_title(spec: SettingSpec) -> str:
    return spec.path


def _setting_title(spec: SettingSpec) -> str:
    return _TITLE_BY_PATH.get(spec.path, spec.title or spec.path)


def _hint_description(spec: SettingSpec) -> str:
    text = str(_DESCRIPTION_BY_PATH.get(spec.path) or spec.description or "").strip()
    if not text:
        text = f"РЈРїСЂР°РІР»СЏРµС‚ РїР°СЂР°РјРµС‚СЂРѕРј {spec.path}. Р—РЅР°С‡РµРЅРёРµ РїСЂРёРјРµРЅСЏРµС‚СЃСЏ РїСЂРё СЃРѕС…СЂР°РЅРµРЅРёРё РЅР°СЃС‚СЂРѕРµРє."
    if spec.dangerous:
        text = f"{text}\n\nРћРїР°СЃРЅС‹Р№ РїР°СЂР°РјРµС‚СЂ: РјРµРЅСЏР№ С‚РѕР»СЊРєРѕ РµСЃР»Рё РїРѕРЅРёРјР°РµС€СЊ РїРѕСЃР»РµРґСЃС‚РІРёСЏ."
    return text


def _hint_example(spec: SettingSpec) -> str:
    if spec.example:
        return str(spec.example)
    if spec.options:
        return " / ".join(str(option) for option in spec.options)
    return ""


def _hint_popup_width(spec: SettingSpec) -> int:
    from PySide6.QtGui import QFontMetrics

    font = _ui_font(pixel_size=11)
    font.setFamily("Cascadia Code")
    metrics = QFontMetrics(font)
    description = _hint_description(spec)
    example = _hint_example(spec)
    words = description.replace("\n", " ").split()
    longest_word_width = max((metrics.horizontalAdvance(word) for word in words), default=0)
    example_width = max((metrics.horizontalAdvance(line) for line in example.splitlines()), default=0)
    title_width = metrics.horizontalAdvance(spec.path)

    target = max(252, title_width + 58, longest_word_width + 90, min(example_width + 58, 360))
    if len(description) > 220 or len(example) > 90:
        target = max(target, 334)
    elif len(description) > 150 or len(example) > 60:
        target = max(target, 314)
    return min(360, target)


_TITLE_BY_PATH: dict[str, str] = {
    "app.name": "РќР°Р·РІР°РЅРёРµ РїСЂРёР»РѕР¶РµРЅРёСЏ",
    "app.locale": "Р›РѕРєР°Р»СЊ РїСЂРёР»РѕР¶РµРЅРёСЏ",
    "app.default_language": "РЇР·С‹Рє РїРѕ СѓРјРѕР»С‡Р°РЅРёСЋ",
    "app.debug": "Debug mode",
    "startup.mode": "Р РµР¶РёРј Р·Р°РїСѓСЃРєР°",
    "startup.active_profile": "РђРєС‚РёРІРЅС‹Р№ РїСЂРѕС„РёР»СЊ",
    "startup.safety_mode": "Р РµР¶РёРј Р±РµР·РѕРїР°СЃРЅРѕСЃС‚Рё",
    "api.host": "API host",
    "api.port": "API port",
    "ui.api.active_endpoint": "РђРєС‚РёРІРЅС‹Р№ API endpoint",
    "ui.api.local_base_url": "Р›РѕРєР°Р»СЊРЅС‹Р№ API URL",
    "ui.api.public_base_url": "РџСѓР±Р»РёС‡РЅС‹Р№ API URL",
    "llm.provider": "РџСЂРѕРІР°Р№РґРµСЂ LLM",
    "llm.model_name": "РћСЃРЅРѕРІРЅР°СЏ РјРѕРґРµР»СЊ",
    "llm.thinking_enabled": "Thinking",
    "llm.json_mode_enabled": "JSON mode",
    "llm.model_fallbacks": "Fallback РјРѕРґРµР»Рё",
    "llm.providers.ollama.base_url": "Ollama URL",
    "llm.providers.ollama.timeout_sec": "Ollama timeout",
    "llm.providers.ollama.retries": "Ollama retries",
    "llm.providers.openai.api_key": "OpenAI API key",
    "llm.providers.openai.api_url": "OpenAI API URL",
    "llm.providers.openai.timeout_sec": "OpenAI timeout",
    "llm.providers.openai.max_retries": "OpenAI retries",
    "memory.enabled": "РџР°РјСЏС‚СЊ",
    "memory.memory_dir": "РџР°РїРєР° РїР°РјСЏС‚Рё",
    "memory.cache_dir": "РџР°РїРєР° РєРµС€Р°",
    "memory.db_path": "Р‘Р°Р·Р° РїР°РјСЏС‚Рё",
    "memory.chat_recall_results": "Recall results",
    "memory.chat_events_limit": "Events limit",
    "memory.chat_proofread": "Proofread РїР°РјСЏС‚Рё",
    "memory.chat_proofread_strict": "РЎС‚СЂРѕРіРёР№ proofread",
    "memory_core.enabled": "Memory Core",
    "memory_core.worker_enabled": "Р¤РѕРЅРѕРІС‹Р№ РІРѕСЂРєРµСЂ",
    "memory_core.worker_poll_interval": "РРЅС‚РµСЂРІР°Р» РІРѕСЂРєРµСЂР°",
    "internet.enabled": "РРЅС‚РµСЂРЅРµС‚",
    "internet.web_mode": "Web mode",
    "internet.search.provider": "Search provider",
    "internet.search.api_url": "Search API URL",
    "internet.search.timeout_sec": "Search timeout",
    "internet.fetch.timeout_sec": "Fetch timeout",
    "internet.fetch.retries": "Fetch retries",
    "internet.fetch.clean_max_chars": "Clean max chars",
    "internet.fetch.clean_min_chars": "Clean min chars",
    "internet.web_v2": "Web v2 config",
    "voice.enabled": "Р“РѕР»РѕСЃ",
    "voice.mode": "Р РµР¶РёРј РіРѕР»РѕСЃР°",
    "voice.open_mode_from_rail": "РћС‚РєСЂС‹РІР°С‚СЊ voice РёР· rail",
    "voice.auto_speak_replies": "РђРІС‚РѕРѕР·РІСѓС‡РєР°",
    "voice.barge_in": "Barge-in",
    "voice.stt_engine": "STT engine",
    "voice.stt_model": "STT model",
    "voice.stt_device": "STT device",
    "voice.stt_compute_type": "STT compute type",
    "voice.stt_language_hint": "STT language",
    "voice.tts_engine": "TTS engine",
    "voice.tts_model": "TTS model",
    "voice.tts_device": "TTS device",
    "voice.tts.voice": "TTS voice",
    "voice.tts.rate": "TTS rate",
    "voice.tts.volume": "TTS volume",
    "dialog.new_session_after_min": "РќРѕРІР°СЏ СЃРµСЃСЃРёСЏ",
    "dialog.greeting_max_words": "Greeting max words",
    "dialog.greeting_max_chars": "Greeting max chars",
    "dialog.greetings": "РџСЂРёРІРµС‚СЃС‚РІРёСЏ",
    "dialog.greeting_exclusions": "РСЃРєР»СЋС‡РµРЅРёСЏ РїСЂРёРІРµС‚СЃС‚РІРёР№",
    "ui.console.timeout_sec": "Console timeout",
    "ui.console.stream_timeout_sec": "Stream timeout",
    "ui.console.store_turn": "Store turn",
    "ui.console.show_thinking": "РџРѕРєР°Р·С‹РІР°С‚СЊ thinking",
    "ui.console.thinking_first": "Thinking РїРµСЂРІС‹Рј",
    "ui.console.auto_start_api": "РђРІС‚РѕСЃС‚Р°СЂС‚ API",
    "ui.console.auto_start_ollama": "РђРІС‚РѕСЃС‚Р°СЂС‚ Ollama",
    "debug.memory_inspector_enabled": "Memory Inspector",
    "debug.show_raw_scores": "Raw scores",
    "debug.show_filtered_items": "Filtered items",
    "debug.show_prompt_blocks": "Prompt blocks",
    "logging.level": "РЈСЂРѕРІРµРЅСЊ Р»РѕРіРѕРІ",
    "logging.file": "Р¤Р°Р№Р» Р»РѕРіРѕРІ",
    "logging.colors": "Р¦РІРµС‚РЅС‹Рµ Р»РѕРіРё",
    "logging.max_bytes": "Р Р°Р·РјРµСЂ Р»РѕРі-С„Р°Р№Р»Р°",
    "logging.backup_count": "РљРѕР»РёС‡РµСЃС‚РІРѕ backup",
    "logging.format": "Р¤РѕСЂРјР°С‚ Р»РѕРіРѕРІ",
    "logging.web_trace_enabled": "Web trace",
    "logging.web_trace_logger": "Web trace logger",
    "logging.channels": "РљР°РЅР°Р»С‹ Р»РѕРіРѕРІ",
    "modules.automation_enabled": "Automation",
    "modules.screen_enabled": "Screen tools",
    "prompt.response_safety_filter_enabled": "Safety filter",
    "prompt.response_formatting_enabled": "Response formatting",
}


_DESCRIPTION_BY_PATH: dict[str, str] = {
    "app.name": "РРјСЏ, РєРѕС‚РѕСЂРѕРµ РїРѕРєР°Р·С‹РІР°РµС‚СЃСЏ РІ UI, Р»РѕРіР°С… Рё СЃР»СѓР¶РµР±РЅС‹С… СЃРѕРѕР±С‰РµРЅРёСЏС… РїСЂРёР»РѕР¶РµРЅРёСЏ.",
    "app.locale": "Р›РѕРєР°Р»СЊ РёРЅС‚РµСЂС„РµР№СЃР° Рё С„РѕСЂРјР°С‚РёСЂРѕРІР°РЅРёСЏ. Р’Р»РёСЏРµС‚ РЅР° СЏР·С‹РєРѕРІС‹Рµ РїРѕРґСЃРєР°Р·РєРё Рё СЂРµРіРёРѕРЅР°Р»СЊРЅС‹Рµ Р·РЅР°С‡РµРЅРёСЏ.",
    "app.default_language": "РћСЃРЅРѕРІРЅРѕР№ СЏР·С‹Рє РѕС‚РІРµС‚РѕРІ Рё РІРЅСѓС‚СЂРµРЅРЅРёС… РїРѕРґСЃРєР°Р·РѕРє, РµСЃР»Рё РїРѕР»СЊР·РѕРІР°С‚РµР»СЊ СЏРІРЅРѕ РЅРµ РІС‹Р±СЂР°Р» РґСЂСѓРіРѕР№.",
    "app.debug": "Р’РєР»СЋС‡Р°РµС‚ СЂР°СЃС€РёСЂРµРЅРЅСѓСЋ РґРёР°РіРЅРѕСЃС‚РёРєСѓ Рё Р±РѕР»СЊС€Рµ СЃР»СѓР¶РµР±РЅРѕР№ РёРЅС„РѕСЂРјР°С†РёРё РІ Р»РѕРіР°С….",
    "startup.mode": "РћРїСЂРµРґРµР»СЏРµС‚, РєР°Рє СЃС‚Р°СЂС‚СѓРµС‚ РїСЂРёР»РѕР¶РµРЅРёРµ: API, UI РёР»Рё РєРѕРјР±РёРЅРёСЂРѕРІР°РЅРЅС‹Р№ СЂРµР¶РёРј.",
    "startup.active_profile": "Р’С‹Р±РёСЂР°РµС‚ РїСЂРѕС„РёР»СЊ РїСЂРѕРёР·РІРѕРґРёС‚РµР»СЊРЅРѕСЃС‚Рё РёР· performance_profiles.json РґР»СЏ РѕСЃРЅРѕРІРЅРѕРіРѕ LLM runtime.",
    "startup.safety_mode": "РћРіСЂР°РЅРёС‡РёРІР°РµС‚ РёР»Рё СЂР°Р·СЂРµС€Р°РµС‚ РїРѕС‚РµРЅС†РёР°Р»СЊРЅРѕ РѕРїР°СЃРЅС‹Рµ РґРµР№СЃС‚РІРёСЏ РёРЅСЃС‚СЂСѓРјРµРЅС‚РѕРІ Рё Р°РІС‚РѕРјР°С‚РёР·Р°С†РёРё.",
    "api.host": "РђРґСЂРµСЃ, РЅР° РєРѕС‚РѕСЂРѕРј API-СЃРµСЂРІРµСЂ РїСЂРёРЅРёРјР°РµС‚ РїРѕРґРєР»СЋС‡РµРЅРёСЏ. 127.0.0.1 С‚РѕР»СЊРєРѕ Р»РѕРєР°Р»СЊРЅРѕ, 0.0.0.0 РґР»СЏ СЃРµС‚Рё.",
    "api.port": "РџРѕСЂС‚ FastAPI/uvicorn СЃРµСЂРІРµСЂР°. UI Рё РІРЅРµС€РЅРёРµ РєР»РёРµРЅС‚С‹ РґРѕР»Р¶РЅС‹ С…РѕРґРёС‚СЊ РЅР° СЌС‚РѕС‚ РїРѕСЂС‚.",
    "ui.api.active_endpoint": "Р’С‹Р±РёСЂР°РµС‚, РєСѓРґР° РґРµСЃРєС‚РѕРїРЅС‹Р№ UI Р±СѓРґРµС‚ РѕС‚РїСЂР°РІР»СЏС‚СЊ Р·Р°РїСЂРѕСЃС‹: Р»РѕРєР°Р»СЊРЅС‹Р№ РёР»Рё РїСѓР±Р»РёС‡РЅС‹Р№ API endpoint.",
    "ui.api.local_base_url": "URL API РґР»СЏ РїРѕРґРєР»СЋС‡РµРЅРёСЏ СЃ СЌС‚РѕР№ Р¶Рµ РјР°С€РёРЅС‹. РћР±С‹С‡РЅРѕ СЌС‚Рѕ 127.0.0.1 СЃ РїРѕСЂС‚РѕРј РїСЂРёР»РѕР¶РµРЅРёСЏ.",
    "ui.api.public_base_url": "URL API РґР»СЏ РїРѕРґРєР»СЋС‡РµРЅРёСЏ СЃ РґСЂСѓРіРѕРіРѕ СѓСЃС‚СЂРѕР№СЃС‚РІР° РёР»Рё С‡РµСЂРµР· РІРЅРµС€РЅРёР№ Р°РґСЂРµСЃ.",
    "llm.provider": "РћСЃРЅРѕРІРЅРѕР№ backend РіРµРЅРµСЂР°С†РёРё РѕС‚РІРµС‚РѕРІ: Р»РѕРєР°Р»СЊРЅР°СЏ Ollama, OpenAI-compatible endpoint РёР»Рё auto.",
    "llm.model_name": "РњРѕРґРµР»СЊ, РєРѕС‚РѕСЂРѕР№ РѕС‚РІРµС‡Р°РµС‚ РіР»Р°РІРЅС‹Р№ С‡Р°С‚. Р—РЅР°С‡РµРЅРёРµ РґРѕР»Р¶РЅРѕ СЃРѕРІРїР°РґР°С‚СЊ СЃ РёРјРµРЅРµРј РјРѕРґРµР»Рё Сѓ РїСЂРѕРІР°Р№РґРµСЂР°.",
    "llm.thinking_enabled": "Р Р°Р·СЂРµС€Р°РµС‚ reasoning/thinking СЂРµР¶РёРј РґР»СЏ РјРѕРґРµР»РµР№, РєРѕС‚РѕСЂС‹Рµ РµРіРѕ РїРѕРґРґРµСЂР¶РёРІР°СЋС‚.",
    "llm.json_mode_enabled": "Р’РєР»СЋС‡Р°РµС‚ JSON mode РїРѕ СѓРјРѕР»С‡Р°РЅРёСЋ РґР»СЏ Р·Р°РїСЂРѕСЃРѕРІ, РєРѕС‚РѕСЂС‹Рј РЅСѓР¶РµРЅ СЃС‚СЂСѓРєС‚СѓСЂРёСЂРѕРІР°РЅРЅС‹Р№ РѕС‚РІРµС‚.",
    "llm.model_fallbacks": "РЎРїРёСЃРѕРє РјРѕРґРµР»РµР№, РєРѕС‚РѕСЂС‹Рµ РјРѕР¶РЅРѕ РїСЂРѕР±РѕРІР°С‚СЊ, РµСЃР»Рё РѕСЃРЅРѕРІРЅР°СЏ РјРѕРґРµР»СЊ РЅРµРґРѕСЃС‚СѓРїРЅР°.",
    "llm.providers.ollama.base_url": "РђРґСЂРµСЃ Ollama API, Рє РєРѕС‚РѕСЂРѕРјСѓ РїРѕРґРєР»СЋС‡Р°РµС‚СЃСЏ РїСЂРёР»РѕР¶РµРЅРёРµ.",
    "llm.providers.ollama.timeout_sec": "РЎРєРѕР»СЊРєРѕ СЃРµРєСѓРЅРґ Р¶РґР°С‚СЊ РѕС‚РІРµС‚ Ollama РґРѕ РѕС€РёР±РєРё timeout.",
    "llm.providers.ollama.retries": "РЎРєРѕР»СЊРєРѕ СЂР°Р· РїРѕРІС‚РѕСЂСЏС‚СЊ Р·Р°РїСЂРѕСЃ Рє Ollama РїРѕСЃР»Рµ РІСЂРµРјРµРЅРЅРѕР№ РѕС€РёР±РєРё.",
    "llm.providers.openai.api_key": "РљР»СЋС‡ РґР»СЏ OpenAI-compatible API. Р•СЃР»Рё С…СЂР°РЅРёС‚СЊ Р·РґРµСЃСЊ, РѕРЅ РїРѕРїР°РґС‘С‚ РІ config.json.",
    "llm.providers.openai.api_url": "Base URL OpenAI-compatible API.",
    "llm.providers.openai.timeout_sec": "РЎРєРѕР»СЊРєРѕ СЃРµРєСѓРЅРґ Р¶РґР°С‚СЊ РѕС‚РІРµС‚ OpenAI-compatible API.",
    "llm.providers.openai.max_retries": "РЎРєРѕР»СЊРєРѕ РїРѕРІС‚РѕСЂРЅС‹С… РїРѕРїС‹С‚РѕРє РґРµР»Р°С‚СЊ РґР»СЏ OpenAI-compatible API.",
    "memory.enabled": "Р’РєР»СЋС‡Р°РµС‚ РёР»Рё РІС‹РєР»СЋС‡Р°РµС‚ СЃР»РѕР№ РїР°РјСЏС‚Рё РґР»СЏ С‡Р°С‚Р°.",
    "memory.memory_dir": "РџР°РїРєР°, РіРґРµ Р»РµР¶Р°С‚ С„Р°Р№Р»С‹ РїР°РјСЏС‚Рё, СЃРѕСЃС‚РѕСЏРЅРёСЏ Рё runtime-Р°СЂС‚РµС„Р°РєС‚С‹.",
    "memory.cache_dir": "РџР°РїРєР° РІСЂРµРјРµРЅРЅРѕРіРѕ РєРµС€Р° РґР»СЏ РїР°РјСЏС‚Рё Рё РІСЃРїРѕРјРѕРіР°С‚РµР»СЊРЅС‹С… РїСЂРѕС†РµСЃСЃРѕРІ.",
    "memory.db_path": "РџСѓС‚СЊ Рє SQLite Р±Р°Р·Рµ Memory Core.",
    "memory.chat_recall_results": "РЎРєРѕР»СЊРєРѕ РЅР°Р№РґРµРЅРЅС‹С… РІРѕСЃРїРѕРјРёРЅР°РЅРёР№ РїРѕРґС‚СЏРіРёРІР°С‚СЊ РІ РєРѕРЅС‚РµРєСЃС‚ РѕС‚РІРµС‚Р°.",
    "memory.chat_events_limit": "РЎРєРѕР»СЊРєРѕ РїРѕСЃР»РµРґРЅРёС… СЃРѕР±С‹С‚РёР№ С‡Р°С‚Р° СѓС‡РёС‚С‹РІР°С‚СЊ РїСЂРё СЃР±РѕСЂРєРµ РєРѕРЅС‚РµРєСЃС‚Р°.",
    "memory.chat_proofread": "Р’РєР»СЋС‡Р°РµС‚ РґРѕРїРѕР»РЅРёС‚РµР»СЊРЅСѓСЋ РїСЂРѕРІРµСЂРєСѓ РїР°РјСЏС‚Рё РїРµСЂРµРґ РёСЃРїРѕР»СЊР·РѕРІР°РЅРёРµРј РІ РѕС‚РІРµС‚Рµ.",
    "memory.chat_proofread_strict": "Р”РµР»Р°РµС‚ РїСЂРѕРІРµСЂРєСѓ РїР°РјСЏС‚Рё СЃС‚СЂРѕР¶Рµ, СЃРЅРёР¶Р°СЏ СЂРёСЃРє РјСѓСЃРѕСЂРЅРѕРіРѕ РєРѕРЅС‚РµРєСЃС‚Р°.",
    "memory_core.enabled": "Р’РєР»СЋС‡Р°РµС‚ РЅРѕРІС‹Р№ Memory Core runtime.",
    "memory_core.worker_enabled": "Р Р°Р·СЂРµС€Р°РµС‚ С„РѕРЅРѕРІСѓСЋ РѕР±СЂР°Р±РѕС‚РєСѓ СЃРѕР±С‹С‚РёР№ РїР°РјСЏС‚Рё.",
    "memory_core.worker_poll_interval": "РРЅС‚РµСЂРІР°Р» РІ СЃРµРєСѓРЅРґР°С…, СЃ РєРѕС‚РѕСЂС‹Рј РІРѕСЂРєРµСЂ РїСЂРѕРІРµСЂСЏРµС‚ РѕС‡РµСЂРµРґСЊ Р·Р°РґР°С‡ РїР°РјСЏС‚Рё.",
    "internet.enabled": "Р Р°Р·СЂРµС€Р°РµС‚ РёРЅС‚РµСЂРЅРµС‚-РјРѕРґСѓР»СЊ Рё web-РїРѕРёСЃРє.",
    "internet.web_mode": "РћРїСЂРµРґРµР»СЏРµС‚ Р°РіСЂРµСЃСЃРёРІРЅРѕСЃС‚СЊ web-РїРѕРёСЃРєР°: off, auto, on РёР»Рё aggressive.",
    "internet.search.provider": "Р’С‹Р±РёСЂР°РµС‚ РїРѕРёСЃРєРѕРІС‹Р№ backend, РЅР°РїСЂРёРјРµСЂ Р»РѕРєР°Р»СЊРЅС‹Р№ SearXNG.",
    "internet.search.api_url": "Endpoint РїРѕРёСЃРєРѕРІРѕРіРѕ API.",
    "internet.search.timeout_sec": "РЎРєРѕР»СЊРєРѕ СЃРµРєСѓРЅРґ Р¶РґР°С‚СЊ РѕС‚РІРµС‚ РїРѕРёСЃРєРѕРІРѕРіРѕ СЃРµСЂРІРёСЃР°.",
    "internet.fetch.timeout_sec": "РЎРєРѕР»СЊРєРѕ СЃРµРєСѓРЅРґ Р¶РґР°С‚СЊ Р·Р°РіСЂСѓР·РєСѓ СЃС‚СЂР°РЅРёС†С‹.",
    "internet.fetch.retries": "РЎРєРѕР»СЊРєРѕ СЂР°Р· РїРѕРІС‚РѕСЂСЏС‚СЊ fetch РїРѕСЃР»Рµ РІСЂРµРјРµРЅРЅРѕР№ РѕС€РёР±РєРё.",
    "internet.fetch.clean_max_chars": "РњР°РєСЃРёРјР°Р»СЊРЅС‹Р№ СЂР°Р·РјРµСЂ РѕС‡РёС‰РµРЅРЅРѕРіРѕ С‚РµРєСЃС‚Р° СЃС‚СЂР°РЅРёС†С‹.",
    "internet.fetch.clean_min_chars": "РњРёРЅРёРјР°Р»СЊРЅС‹Р№ СЂР°Р·РјРµСЂ С‚РµРєСЃС‚Р°, РїСЂРё РєРѕС‚РѕСЂРѕРј СЃС‚СЂР°РЅРёС†Р° СЃС‡РёС‚Р°РµС‚СЃСЏ РїРѕР»РµР·РЅРѕР№.",
    "internet.web_v2": "Р Р°СЃС€РёСЂРµРЅРЅР°СЏ JSON-РєРѕРЅС„РёРіСѓСЂР°С†РёСЏ web policy, Р±СЋРґР¶РµС‚РѕРІ, trust policy Рё citations.",
    "voice.enabled": "Р’РєР»СЋС‡Р°РµС‚ РіРѕР»РѕСЃРѕРІС‹Рµ С„СѓРЅРєС†РёРё РїСЂРёР»РѕР¶РµРЅРёСЏ.",
    "voice.mode": "РћРїСЂРµРґРµР»СЏРµС‚, РєР°Рє СЂР°Р±РѕС‚Р°РµС‚ РіРѕР»РѕСЃРѕРІРѕР№ РІРІРѕРґ: push-to-talk РёР»Рё РїРµСЂРµРєР»СЋС‡Р°С‚РµР»СЊ.",
    "voice.open_mode_from_rail": "Р Р°Р·СЂРµС€Р°РµС‚ РѕС‚РєСЂС‹РІР°С‚СЊ РіРѕР»РѕСЃРѕРІРѕР№ СЌРєСЂР°РЅ РєРЅРѕРїРєРѕР№ РІ Р»РµРІРѕР№ РїР°РЅРµР»Рё.",
    "voice.auto_speak_replies": "РђРІС‚РѕРјР°С‚РёС‡РµСЃРєРё РѕР·РІСѓС‡РёРІР°РµС‚ РѕС‚РІРµС‚С‹ Р°СЃСЃРёСЃС‚РµРЅС‚Р°.",
    "voice.barge_in": "РџРѕР·РІРѕР»СЏРµС‚ РїРµСЂРµР±РёС‚СЊ РѕР·РІСѓС‡РєСѓ РЅРѕРІС‹Рј РіРѕР»РѕСЃРѕРІС‹Рј РІРІРѕРґРѕРј.",
    "voice.stt_engine": "Р”РІРёР¶РѕРє СЂР°СЃРїРѕР·РЅР°РІР°РЅРёСЏ СЂРµС‡Рё.",
    "voice.stt_model": "РњРѕРґРµР»СЊ СЂР°СЃРїРѕР·РЅР°РІР°РЅРёСЏ СЂРµС‡Рё.",
    "voice.stt_device": "РЈСЃС‚СЂРѕР№СЃС‚РІРѕ РґР»СЏ STT: cuda, cpu РёР»Рё auto.",
    "voice.stt_compute_type": "РўРёРї РІС‹С‡РёСЃР»РµРЅРёР№ STT, РІР»РёСЏСЋС‰РёР№ РЅР° СЃРєРѕСЂРѕСЃС‚СЊ Рё VRAM/RAM.",
    "voice.stt_language_hint": "РЇР·С‹РєРѕРІР°СЏ РїРѕРґСЃРєР°Р·РєР° РґР»СЏ СЂР°СЃРїРѕР·РЅР°РІР°РЅРёСЏ СЂРµС‡Рё.",
    "voice.tts_engine": "Р”РІРёР¶РѕРє РѕР·РІСѓС‡РєРё РѕС‚РІРµС‚РѕРІ.",
    "voice.tts_model": "РњРѕРґРµР»СЊ СЃРёРЅС‚РµР·Р° СЂРµС‡Рё.",
    "voice.tts_device": "РЈСЃС‚СЂРѕР№СЃС‚РІРѕ РґР»СЏ TTS: cuda, cpu РёР»Рё auto.",
    "voice.tts.voice": "Р“РѕР»РѕСЃ РёР»Рё РїСЂРµСЃРµС‚, РєРѕС‚РѕСЂС‹Р№ РёСЃРїРѕР»СЊР·СѓРµС‚СЃСЏ TTS.",
    "voice.tts.rate": "РЎРєРѕСЂРѕСЃС‚СЊ СЂРµС‡Рё TTS.",
    "voice.tts.volume": "Р“СЂРѕРјРєРѕСЃС‚СЊ СЂРµС‡Рё TTS.",
    "dialog.new_session_after_min": "Р§РµСЂРµР· СЃРєРѕР»СЊРєРѕ РјРёРЅСѓС‚ РїСЂРѕСЃС‚РѕСЏ РЅР°С‡РёРЅР°С‚СЊ РЅРѕРІСѓСЋ РґРёР°Р»РѕРіРѕРІСѓСЋ СЃРµСЃСЃРёСЋ.",
    "dialog.greeting_max_words": "РњР°РєСЃРёРјСѓРј СЃР»РѕРІ РІ Р°РІС‚РѕРїСЂРёРІРµС‚СЃС‚РІРёРё.",
    "dialog.greeting_max_chars": "РњР°РєСЃРёРјСѓРј СЃРёРјРІРѕР»РѕРІ РІ Р°РІС‚РѕРїСЂРёРІРµС‚СЃС‚РІРёРё.",
    "dialog.greetings": "РЎРїРёСЃРѕРє СЂР°Р·СЂРµС€С‘РЅРЅС‹С… РІР°СЂРёР°РЅС‚РѕРІ РїСЂРёРІРµС‚СЃС‚РІРёР№.",
    "dialog.greeting_exclusions": "РЎР»РѕРІР° Рё С€Р°Р±Р»РѕРЅС‹, РїСЂРё РєРѕС‚РѕСЂС‹С… РїСЂРёРІРµС‚СЃС‚РІРёРµ РЅРµ РїРѕРєР°Р·С‹РІР°РµС‚СЃСЏ.",
    "ui.console.timeout_sec": "Timeout РєРѕСЂРѕС‚РєРёС… API-Р·Р°РїСЂРѕСЃРѕРІ РёР· UI/console.",
    "ui.console.stream_timeout_sec": "Timeout РїРѕС‚РѕРєРѕРІРѕРіРѕ РѕС‚РІРµС‚Р° С‡Р°С‚Р°.",
    "ui.console.store_turn": "РЎРѕС…СЂР°РЅСЏС‚СЊ СЂРµРїР»РёРєРё РІ РёСЃС‚РѕСЂРёСЋ Рё РїР°РјСЏС‚СЊ.",
    "ui.console.show_thinking": "РџРѕРєР°Р·С‹РІР°С‚СЊ Р±Р»РѕРє thinking РІ РёРЅС‚РµСЂС„РµР№СЃРµ.",
    "ui.console.thinking_first": "РџРѕРєР°Р·С‹РІР°С‚СЊ thinking РїРµСЂРµРґ С„РёРЅР°Р»СЊРЅС‹Рј РѕС‚РІРµС‚РѕРј.",
    "ui.console.auto_start_api": "РђРІС‚РѕРјР°С‚РёС‡РµСЃРєРё СЃС‚Р°СЂС‚РѕРІР°С‚СЊ API РїСЂРё Р·Р°РїСѓСЃРєРµ UI/console.",
    "ui.console.auto_start_ollama": "РђРІС‚РѕРјР°С‚РёС‡РµСЃРєРё СЃС‚Р°СЂС‚РѕРІР°С‚СЊ Ollama РїСЂРё Р·Р°РїСѓСЃРєРµ UI/console.",
    "debug.memory_inspector_enabled": "Р’РєР»СЋС‡Р°РµС‚ Memory Inspector РІ РёРЅС‚РµСЂС„РµР№СЃРµ.",
    "debug.show_raw_scores": "РџРѕРєР°Р·С‹РІР°РµС‚ СЃС‹СЂС‹Рµ РѕС†РµРЅРєРё retrieval/scoring.",
    "debug.show_filtered_items": "РџРѕРєР°Р·С‹РІР°РµС‚ СЌР»РµРјРµРЅС‚С‹, РѕС‚С„РёР»СЊС‚СЂРѕРІР°РЅРЅС‹Рµ РёР· memory retrieval.",
    "debug.show_prompt_blocks": "РџРѕРєР°Р·С‹РІР°РµС‚ Р±Р»РѕРєРё РїСЂРѕРјРїС‚Р° РґР»СЏ РѕС‚Р»Р°РґРєРё СЃР±РѕСЂРєРё РєРѕРЅС‚РµРєСЃС‚Р°.",
    "logging.level": "РњРёРЅРёРјР°Р»СЊРЅС‹Р№ СѓСЂРѕРІРµРЅСЊ СЃРѕРѕР±С‰РµРЅРёР№, РєРѕС‚РѕСЂС‹Рµ РїРёС€СѓС‚СЃСЏ РІ Р»РѕРі.",
    "logging.file": "Р¤Р°Р№Р», РєСѓРґР° РїРёС€СѓС‚СЃСЏ Р»РѕРіРё РїСЂРёР»РѕР¶РµРЅРёСЏ.",
    "logging.colors": "Р’РєР»СЋС‡Р°РµС‚ С†РІРµС‚РЅРѕР№ РІС‹РІРѕРґ Р»РѕРіРѕРІ РІ РєРѕРЅСЃРѕР»Рё.",
    "logging.max_bytes": "РњР°РєСЃРёРјР°Р»СЊРЅС‹Р№ СЂР°Р·РјРµСЂ РѕРґРЅРѕРіРѕ Р»РѕРі-С„Р°Р№Р»Р° РґРѕ СЂРѕС‚Р°С†РёРё.",
    "logging.backup_count": "РљРѕР»РёС‡РµСЃС‚РІРѕ СЃС‚Р°СЂС‹С… Р»РѕРі-С„Р°Р№Р»РѕРІ, РєРѕС‚РѕСЂС‹Рµ СЃРѕС…СЂР°РЅСЏСЋС‚СЃСЏ РїСЂРё СЂРѕС‚Р°С†РёРё.",
    "logging.format": "Р¤РѕСЂРјР°С‚ СЃС‚СЂРѕРєРё Р»РѕРіРѕРІ.",
    "logging.web_trace_enabled": "Р’РєР»СЋС‡Р°РµС‚ РѕС‚РґРµР»СЊРЅС‹Р№ trace web-РїР°Р№РїР»Р°Р№РЅР°.",
    "logging.web_trace_logger": "РРјСЏ logger РґР»СЏ web trace.",
    "logging.channels": "JSON-РЅР°СЃС‚СЂРѕР№РєР° РєР°РЅР°Р»РѕРІ Р»РѕРіРёСЂРѕРІР°РЅРёСЏ Рё РёС… prefix-С„РёР»СЊС‚СЂРѕРІ.",
    "modules.automation_enabled": "Р Р°Р·СЂРµС€Р°РµС‚ РјРѕРґСѓР»СЊ Р°РІС‚РѕРјР°С‚РёР·Р°С†РёРё РґРµР№СЃС‚РІРёР№.",
    "modules.screen_enabled": "Р Р°Р·СЂРµС€Р°РµС‚ screen/OCR РёРЅСЃС‚СЂСѓРјРµРЅС‚С‹.",
    "prompt.response_safety_filter_enabled": "Р’РєР»СЋС‡Р°РµС‚ С„РёР»СЊС‚СЂ Р±РµР·РѕРїР°СЃРЅРѕСЃС‚Рё С„РёРЅР°Р»СЊРЅРѕРіРѕ РѕС‚РІРµС‚Р°.",
    "prompt.response_formatting_enabled": "Р’РєР»СЋС‡Р°РµС‚ РїРѕСЃС‚РѕР±СЂР°Р±РѕС‚РєСѓ С„РѕСЂРјР°С‚РёСЂРѕРІР°РЅРёСЏ РѕС‚РІРµС‚Р°.",
}


def _group_title(group: str) -> str:
    mapping = {
        "Core": "РћРЎРќРћР’РќРћР•",
        "Modules": "РњРћР”РЈР›Р",
        "System": "РЎРРЎРўР•РњРђ",
    }
    return mapping.get(str(group or ""), str(group or "").upper())


def _category_icon(key: str) -> str:
    return {
        "main": "вЊ‚",
        "memory": "в—Џ",
        "llm": "в—†",
        "web": "в—‰",
        "voice": "вЊ•",
        "dialog_ui": "в–Ј",
        "debug": "вљ™",
        "logging": "в–Ў",
        "safety": "!",
    }.get(str(key or ""), "вЂў")


def _category_description(category: SettingCategory) -> str:
    descriptions = {
        "main": "Р‘Р°Р·РѕРІС‹Рµ РїР°СЂР°РјРµС‚СЂС‹ РїСЂРёР»РѕР¶РµРЅРёСЏ, API, СЂРµР¶РёРј Р·Р°РїСѓСЃРєР° Рё Р±РµР·РѕРїР°СЃРЅС‹Рµ С„Р»Р°РіРё. РќСѓР¶РЅС‹Рµ РїРѕРґСЃРєР°Р·РєРё РїРѕСЏРІР»СЏСЋС‚СЃСЏ РїСЂРё РЅР°РІРµРґРµРЅРёРё РЅР° Р·РЅР°Рє РІРѕРїСЂРѕСЃР°.",
        "llm": "РћСЃРЅРѕРІРЅР°СЏ РјРѕРґРµР»СЊ, РїСЂРѕРІР°Р№РґРµСЂС‹ Рё runtime-С„Р»Р°РіРё. Р›РёРјРёС‚РѕРІ max_tokens Р·РґРµСЃСЊ РЅРµС‚: РґР»РёРЅСѓ РґРµСЂР¶Р°С‚ num_ctx Рё num_batch.",
        "memory": "РџСѓС‚Рё, РІРѕСЂРєРµСЂ РїР°РјСЏС‚Рё Рё РїР°СЂР°РјРµС‚СЂС‹ retrieval РґР»СЏ РєРѕРЅС‚РµРєСЃС‚Р° С‡Р°С‚Р°.",
        "web": "РџРѕРёСЃРє, fetch, web mode Рё РїРѕР»РёС‚РёРєР° РІРЅРµС€РЅРёС… РёСЃС‚РѕС‡РЅРёРєРѕРІ.",
        "voice": "STT, TTS, РіРѕР»РѕСЃРѕРІРѕР№ СЂРµР¶РёРј Рё СѓСЃС‚СЂРѕР№СЃС‚РІР°.",
        "dialog_ui": "РџРѕРІРµРґРµРЅРёРµ РґРёР°Р»РѕРіР°, РєРѕРЅСЃРѕР»СЊРЅС‹Рµ С„Р»Р°РіРё Рё РѕС‚РѕР±СЂР°Р¶РµРЅРёРµ thinking.",
        "debug": "Inspector, prompt blocks Рё РґРёР°РіРЅРѕСЃС‚РёС‡РµСЃРєРёРµ РїР°РЅРµР»Рё.",
        "logging": "Р›РѕРіРё, СЂРѕС‚Р°С†РёСЏ, РєР°РЅР°Р»С‹ Рё web trace.",
        "safety": "РћРїР°СЃРЅС‹Рµ РїРµСЂРµРєР»СЋС‡Р°С‚РµР»Рё Р°РІС‚РѕРјР°С‚РёР·Р°С†РёРё Рё safety-С„РёР»СЊС‚СЂРѕРІ.",
    }
    return descriptions.get(category.key, category.description)


def _spec_for(path: str) -> SettingSpec | None:
    for category in SETTINGS_CATEGORIES:
        for card in category.cards:
            for spec in card.settings:
                if spec.path == path:
                    return spec
    return None

